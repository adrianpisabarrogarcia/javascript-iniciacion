"use strict"

for (let i = 0; i<10; i++){
    for (let j= 0; j<i; j++){
        document.write(i)
    }
    document.write("<br>")
}