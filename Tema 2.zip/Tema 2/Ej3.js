"use scrict"
var nombre = prompt("Indica tu nombre:")
var edad = prompt("Indica tu edad:")
var incremento = prompt("Indica cuanto incrementarías:")
var nuevaEdad = parseInt(edad)  + parseInt(incremento)
alert ("La nueva edad es " + nuevaEdad)