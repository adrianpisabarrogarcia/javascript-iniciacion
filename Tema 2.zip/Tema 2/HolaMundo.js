alert("HolaMundo!");
var nombre = prompt("Dime tu nombre");
alert("Hola "+ nombre);
var continuar = confirm("Quieres continuar?");
alert(continuar);
var apellido = prompt("Dime tu apellido", "Ruiz");
console.log("Hola");
document.write("<br>HolaMundo3");