"use sctrict"
var num1 = prompt("Introduce un número")
var num2 = prompt("introduce otro numero")

num1 = parseInt(num1)
num2 = parseInt(num2)

alert("La suma es: " + (num1 + num2))
alert("La resta es: " + (num1 - num2))
alert("La multiplicación es: " + (num1 * num2))
alert("La division es: " + (num1 / num2))
alert("El resto de la division es: " + (num1 % num2))


