alert("HolaMundo!")
console.log("HolaMundo!")
document.write("HolaMundo!")