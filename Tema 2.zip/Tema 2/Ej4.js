"use strict"
var cadena1 = prompt("Introduce texto", "cadena1")
var cadena2 = prompt("Introduce texto", "cadena2")
alert(cadena1 + " " + cadena2)