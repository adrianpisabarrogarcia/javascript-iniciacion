"use strict"
var num = parseInt(prompt("Introduce un número: "))

if(num % 2 == 0){
    alert("El número es par")
}else{
    alert("El número es impar")
}