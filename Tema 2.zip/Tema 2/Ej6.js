"use strict"
var num = parseInt(prompt("Introduce un número:"))
alert("El cuadrado de " + num +" es " + Math.pow(num, 2)+"\n El cubo de " + num +" es " + Math.pow(num, 3))
