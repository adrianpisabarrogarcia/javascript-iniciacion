"use strict";
var nombre = prompt("¿Cuál es es tu nombre?");
alert("Hola " + nombre)