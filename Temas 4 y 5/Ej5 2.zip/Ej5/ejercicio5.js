var productos = []

function annadirCesta() {
    let producto = document.getElementById('producto').value
    productos.push(producto)
    mostrarProductoLista(producto)
}

function mostrarProductoLista(producto) {
    let lista = document.getElementsByTagName("ul")[0]

    let elemento = document.createElement("li")
    elemento.innerText = producto
    lista.appendChild(elemento)
    elemento.addEventListener('dblclick', function (e) {
        lista.removeChild(this)

        let j
        for (j = 0; j < personas.length && this.innerHTML != personas[j]; j++) {
        }
        if (j != personas.length) {
            personas.slice(j, 1)
        }
        console.log("ojala llegues aqui js")
    })


    insertarCookies()
}

function insertarCookies() {
    let text = "productos= "
    for (let i = 0; i < productos.length; i++) {
        text += productos[i]
        text += " "
    }
    document.cookie = text
}

function resetearCookies() {
    document.cookie = "productos=;expires=Thu, 01 Jan 1970 00:00:01 GMT;"
}

window.onload = function cargarCookies() {
    let cookies = document.cookie
    if (!cookies.matchAll("productos=") || !cookies.matchAll("")) {
        let producto = ""
        let contador = 0
        for (let i = 0; i < cookies.length; i++) {
            if (cookies.charAt(" ")) {
                producto.push(producto)
                producto = ""
                contador = 0
                contador++
            }
            if (contador > 1) {
                producto += cookies.charAt(i)
            }
        }
    }
}

